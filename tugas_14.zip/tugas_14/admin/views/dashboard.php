<?php
require_once __DIR__ . '/../../helpers/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Sistem Manajemen Beasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --dark-color: #1e293b;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4edf5 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.85);
            padding: 15px 25px;
            border-radius: 8px;
            margin: 5px 15px;
            transition: all 0.3s;
            font-weight: 600;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.2);
        }
        
        .sidebar .nav-link i {
            margin-right: 12px;
            width: 25px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 25px;
            transition: transform 0.3s;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 18px 25px;
            font-weight: 700;
        }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }
        
        .stat-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 32px;
        }
        
        .stat-number {
            font-size: 2.8rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 10px;
        }
        
        .stat-label {
            color: var(--dark-color);
            font-weight: 700;
            font-size: 1.2rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: none;
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.4);
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 18px 25px;
            margin-bottom: 25px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center">
            <h4 class="text-white mb-1"><i class="fas fa-crown"></i> ADMIN</h4>
            <small class="text-white-50">Beasiswa Management</small>
        </div>
        <hr class="text-white-50">
        
        <ul class="nav flex-column px-3 mt-3">
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' && (!isset($_GET['action']) || $_GET['action'] == 'dashboard') ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>index.php?page=admin&action=dashboard">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= isset($_GET['action']) && $_GET['action'] == 'beasiswa' ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>index.php?page=admin&action=beasiswa">
                    <i class="fas fa-book-open"></i> Kelola Beasiswa
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= isset($_GET['action']) && $_GET['action'] == 'users' ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>index.php?page=admin&action=users">
                    <i class="fas fa-users"></i> Kelola Pengguna
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= isset($_GET['action']) && $_GET['action'] == 'aplikasi' ? 'active' : '' ?>" 
                   href="<?= BASE_URL ?>index.php?page=admin&action=aplikasi">
                    <i class="fas fa-file-alt"></i> Kelola Aplikasi
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=beasiswa">
                    <i class="fas fa-home"></i> Ke Beranda
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light mb-4">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle"></i> <?= e($_SESSION['user_name']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>index.php?page=users&action=profile">
                                    <i class="fas fa-user"></i> Profil
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Flash Message -->
        <?php if ($flash = get_flash()): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'danger' ? 'exclamation-circle' : 'info-circle') ?> me-2"></i>
            <?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Page Title -->
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="fw-bold mb-0"><i class="fas fa-tachometer-alt me-2"></i> Dashboard Admin</h2>
                <p class="text-muted">Selamat datang, <?= e($_SESSION['user_name']) ?>!</p>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-number"><?= $total_users ?></div>
                    <div class="stat-label">Total Pengguna</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="stat-number"><?= $total_beasiswa ?></div>
                    <div class="stat-label">Total Beasiswa</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-number"><?= $total_aplikasi ?></div>
                    <div class="stat-label">Total Aplikasi</div>
                </div>
            </div>
            
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-number"><?= $pending ?></div>
                    <div class="stat-label">Pending Review</div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row">
            <div class="col-12 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-bolt me-2"></i> Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <a href="<?= BASE_URL ?>index.php?page=admin&action=beasiswa" class="btn btn-primary w-100">
                                    <i class="fas fa-plus me-2"></i> Tambah Beasiswa
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?= BASE_URL ?>index.php?page=admin&action=users" class="btn btn-success w-100">
                                    <i class="fas fa-users me-2"></i> Kelola Pengguna
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?= BASE_URL ?>index.php?page=admin&action=aplikasi" class="btn btn-warning w-100">
                                    <i class="fas fa-tasks me-2"></i> Review Aplikasi
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?= BASE_URL ?>index.php?page=beasiswa" class="btn btn-info w-100">
                                    <i class="fas fa-home me-2"></i> Lihat Beranda
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-history me-2"></i> Recent Activity</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info text-center mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            Sistem berjalan normal. Tidak ada aktivitas baru saat ini.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>