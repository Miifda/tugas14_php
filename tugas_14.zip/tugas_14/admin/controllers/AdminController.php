<?php
/**
 * Controller Admin - Sistem Manajemen Beasiswa
 * File: AdminController.php
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

class AdminController {
    private $conn;
    private $table_users = 'users';
    private $table_beasiswa = 'beasiswa';
    private $table_aplikasi = 'aplikasi_beasiswa';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function dashboard() {
        // Statistik
        $query = "SELECT COUNT(*) as total FROM " . $this->table_users . " WHERE role = 'user'";
        $stmt = $this->conn->query($query);
        $total_users = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_beasiswa;
        $stmt = $this->conn->query($query);
        $total_beasiswa = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_aplikasi;
        $stmt = $this->conn->query($query);
        $total_aplikasi = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_aplikasi . " WHERE status = 'pending'";
        $stmt = $this->conn->query($query);
        $pending = $stmt->fetch()['total'];

        $data = [
            'total_users' => $total_users,
            'total_beasiswa' => $total_beasiswa,
            'total_aplikasi' => $total_aplikasi,
            'pending' => $pending,
            'page_title' => 'Dashboard Admin'
        ];
        
        extract($data);
        include __DIR__ . '/../views/dashboard.php';
    }

    public function kelolaBeasiswa() {
        $query = "SELECT * FROM " . $this->table_beasiswa . " ORDER BY created_at DESC";
        $stmt = $this->conn->query($query);
        $beasiswa = $stmt->fetchAll();
        
        $data = [
            'beasiswa' => $beasiswa,
            'page_title' => 'Kelola Beasiswa'
        ];
        
        extract($data);
        include __DIR__ . '/../views/kelola_beasiswa.php';
    }

    public function kelolaUsers() {
        $query = "SELECT * FROM " . $this->table_users . " WHERE role = 'user' ORDER BY created_at DESC";
        $stmt = $this->conn->query($query);
        $users = $stmt->fetchAll();
        
        $data = [
            'users' => $users,
            'page_title' => 'Kelola Pengguna'
        ];
        
        extract($data);
        include __DIR__ . '/../views/kelola_users.php';
    }

    public function kelolaAplikasi() {
        $query = "SELECT a.*, b.nama_beasiswa, u.name as user_name, u.email
                  FROM " . $this->table_aplikasi . " a
                  LEFT JOIN " . $this->table_beasiswa . " b ON a.beasiswa_id = b.id
                  LEFT JOIN " . $this->table_users . " u ON a.user_id = u.id
                  ORDER BY a.tanggal_pengajuan DESC";
        
        $stmt = $this->conn->query($query);
        $aplikasi = $stmt->fetchAll();
        
        $data = [
            'aplikasi' => $aplikasi,
            'page_title' => 'Kelola Aplikasi'
        ];
        
        extract($data);
        include __DIR__ . '/../views/kelola_aplikasi.php';
    }
}
?>