<?php
/**
 * Controller Beasiswa - Sistem Manajemen Beasiswa
 * File: BeasiswaController.php
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../models/BeasiswaModel.php';
require_once __DIR__ . '/../../helpers/auth.php';

class BeasiswaController {
    private $beasiswaModel;
    private $viewPath = __DIR__ . '/../views/beasiswa_view.php';
    private $detailViewPath = __DIR__ . '/../views/detail_beasiswa.php';
    private $aplikasiViewPath = __DIR__ . '/../views/riwayat_aplikasi.php';
    private $adminDashboardView = __DIR__ . '/../views/admin_dashboard.php';
    private $kelolaBeasiswaView = __DIR__ . '/../views/admin_kelola_beasiswa.php';
    private $kelolaUsersView = __DIR__ . '/../views/admin_kelola_users.php';
    private $kelolaAplikasiView = __DIR__ . '/../views/admin_kelola_aplikasi.php';
    private $tambahBeasiswaView = __DIR__ . '/../views/admin_tambah_beasiswa.php';
    private $editBeasiswaView = __DIR__ . '/../views/admin_edit_beasiswa.php';

    public function __construct() {
        $this->beasiswaModel = new BeasiswaModel();
    }

    // ========== USER METHODS ==========
    
    public function index() {
        $beasiswa = $this->beasiswaModel->getAllBeasiswa();
        $stats = $this->beasiswaModel->getStatistik();
        
        $data = [
            'beasiswa' => $beasiswa,
            'stats' => $stats,
            'page_title' => 'Daftar Beasiswa Tersedia'
        ];
        
        extract($data);
        include $this->viewPath;
    }

    public function detail($id) {
        $beasiswa = $this->beasiswaModel->getBeasiswaById($id);
        
        if (!$beasiswa) {
            set_flash('Beasiswa tidak ditemukan', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        $data = [
            'beasiswa' => $beasiswa,
            'page_title' => 'Detail Beasiswa - ' . $beasiswa['nama_beasiswa']
        ];
        
        extract($data);
        include $this->detailViewPath;
    }

    public function ajukan($id) {
        if (!is_logged_in()) {
            set_flash('Anda harus login untuk mengajukan beasiswa', 'warning');
            redirect(BASE_URL . 'index.php?page=users&action=login');
        }
        
        $beasiswa = $this->beasiswaModel->getBeasiswaById($id);
        if (!$beasiswa) {
            set_flash('Beasiswa tidak ditemukan', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        if (strtotime($beasiswa['deadline']) < strtotime(date('Y-m-d'))) {
            set_flash('Maaf, deadline pengajuan beasiswa ini sudah lewat', 'warning');
            redirect(BASE_URL . 'index.php?page=beasiswa&action=detail&id=' . $id);
        }
        
        if (isset($_FILES['berkas']) && $_FILES['berkas']['error'] == 0) {
            $target_dir = "uploads/berkas/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES["berkas"]["name"], PATHINFO_EXTENSION);
            $new_filename = 'berkas_' . $_SESSION['user_id'] . '_' . time() . '.' . $file_extension;
            $target_file = $target_dir . $new_filename;
            
            if (move_uploaded_file($_FILES["berkas"]["tmp_name"], $target_file)) {
                $data = [
                    'beasiswa_id' => $id,
                    'user_id' => $_SESSION['user_id'],
                    'status' => 'pending',
                    'berkas' => $new_filename,
                    'catatan' => $_POST['catatan'] ?? ''
                ];
                
                if ($this->beasiswaModel->createAplikasi($data)) {
                    set_flash('Pengajuan beasiswa berhasil! Silakan tunggu konfirmasi lebih lanjut.', 'success');
                } else {
                    set_flash('Gagal mengajukan beasiswa, silakan coba lagi', 'danger');
                }
            } else {
                set_flash('Gagal mengupload berkas', 'danger');
            }
        } else {
            set_flash('Berkas wajib diupload', 'danger');
        }
        
        redirect(BASE_URL . 'index.php?page=beasiswa&action=riwayat');
    }

    public function riwayat() {
        if (!is_logged_in()) {
            set_flash('Anda harus login untuk melihat riwayat aplikasi', 'warning');
            redirect(BASE_URL . 'index.php?page=users&action=login');
        }
        
        $aplikasi = $this->beasiswaModel->getAplikasiByUserId($_SESSION['user_id']);
        
        $data = [
            'aplikasi' => $aplikasi,
            'page_title' => 'Riwayat Pengajuan Beasiswa'
        ];
        
        extract($data);
        include $this->aplikasiViewPath;
    }

    public function cari() {
        $filter = [];
        
        if (isset($_GET['penyelenggara']) && !empty($_GET['penyelenggara'])) {
            $filter['penyelenggara'] = $_GET['penyelenggara'];
        }
        
        if (isset($_GET['max_nominal']) && !empty($_GET['max_nominal'])) {
            $filter['max_nominal'] = $_GET['max_nominal'];
        }
        
        $beasiswa = $this->beasiswaModel->getBeasiswaByFilter($filter);
        $stats = $this->beasiswaModel->getStatistik();
        
        $data = [
            'beasiswa' => $beasiswa,
            'stats' => $stats,
            'page_title' => 'Hasil Pencarian Beasiswa'
        ];
        
        extract($data);
        include $this->viewPath;
    }

    // ========== ADMIN METHODS ==========
    
    public function adminDashboard() {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        $stats = $this->beasiswaModel->getStatistik();
        
        $data = [
            'stats' => $stats,
            'page_title' => 'Dashboard Admin'
        ];
        
        extract($data);
        include $this->adminDashboardView;
    }

    public function kelolaBeasiswa() {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        $beasiswa = $this->beasiswaModel->getAllBeasiswaWithStatus();
        
        $data = [
            'beasiswa' => $beasiswa,
            'page_title' => 'Kelola Beasiswa'
        ];
        
        extract($data);
        include $this->kelolaBeasiswaView;
    }

    public function kelolaUsers() {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        $users = $this->beasiswaModel->getAllUsers();
        
        $data = [
            'users' => $users,
            'page_title' => 'Kelola Pengguna'
        ];
        
        extract($data);
        include $this->kelolaUsersView;
    }

    public function kelolaAplikasi() {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        $aplikasi = $this->beasiswaModel->getAllAplikasi();
        
        $data = [
            'aplikasi' => $aplikasi,
            'page_title' => 'Kelola Aplikasi'
        ];
        
        extract($data);
        include $this->kelolaAplikasiView;
    }

    public function tambahBeasiswa() {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'nama_beasiswa' => $_POST['nama_beasiswa'],
                'penyelenggara' => $_POST['penyelenggara'],
                'deskripsi' => $_POST['deskripsi'],
                'nominal' => $_POST['nominal'],
                'deadline' => $_POST['deadline'],
                'kriteria' => $_POST['kriteria'],
                'status' => 'aktif'
            ];
            
            if ($this->beasiswaModel->createBeasiswa($data)) {
                set_flash('Beasiswa berhasil ditambahkan!', 'success');
                redirect(BASE_URL . 'index.php?page=admin&action=kelola_beasiswa');
            } else {
                set_flash('Gagal menambahkan beasiswa!', 'danger');
                redirect(BASE_URL . 'index.php?page=admin&action=tambah_beasiswa');
            }
        }
        
        $data = ['page_title' => 'Tambah Beasiswa Baru'];
        extract($data);
        include $this->tambahBeasiswaView;
    }

    public function editBeasiswa($id) {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'nama_beasiswa' => $_POST['nama_beasiswa'],
                'penyelenggara' => $_POST['penyelenggara'],
                'deskripsi' => $_POST['deskripsi'],
                'nominal' => $_POST['nominal'],
                'deadline' => $_POST['deadline'],
                'kriteria' => $_POST['kriteria'],
                'status' => $_POST['status']
            ];
            
            if ($this->beasiswaModel->updateBeasiswa($id, $data)) {
                set_flash('Beasiswa berhasil diupdate!', 'success');
                redirect(BASE_URL . 'index.php?page=admin&action=kelola_beasiswa');
            } else {
                set_flash('Gagal mengupdate beasiswa!', 'danger');
                redirect(BASE_URL . 'index.php?page=admin&action=edit_beasiswa&id=' . $id);
            }
        }
        
        $beasiswa = $this->beasiswaModel->getBeasiswaById($id);
        if (!$beasiswa) {
            set_flash('Beasiswa tidak ditemukan!', 'danger');
            redirect(BASE_URL . 'index.php?page=admin&action=kelola_beasiswa');
        }
        
        $data = [
            'beasiswa' => $beasiswa,
            'page_title' => 'Edit Beasiswa'
        ];
        
        extract($data);
        include $this->editBeasiswaView;
    }

    public function hapusBeasiswa($id) {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        if ($this->beasiswaModel->deleteBeasiswa($id)) {
            set_flash('Beasiswa berhasil dihapus!', 'success');
        } else {
            set_flash('Gagal menghapus beasiswa!', 'danger');
        }
        
        redirect(BASE_URL . 'index.php?page=admin&action=kelola_beasiswa');
    }

    public function updateStatusAplikasi($id, $status) {
        if (!is_admin()) {
            set_flash('Akses ditolak!', 'danger');
            redirect(BASE_URL . 'index.php?page=beasiswa');
        }
        
        $alasan = isset($_POST['alasan']) ? $_POST['alasan'] : null;
        
        if ($this->beasiswaModel->updateStatusAplikasi($id, $status, $alasan)) {
            set_flash('Status aplikasi berhasil diupdate!', 'success');
        } else {
            set_flash('Gagal mengupdate status!', 'danger');
        }
        
        redirect(BASE_URL . 'index.php?page=admin&action=kelola_aplikasi');
    }
}
?>