<?php
/**
 * Model Beasiswa - Sistem Manajemen Beasiswa
 * File: BeasiswaModel.php
 */

require_once __DIR__ . '/../../config/database.php';

class BeasiswaModel {
    private $conn;
    private $table_beasiswa = 'beasiswa';
    private $table_aplikasi = 'aplikasi_beasiswa';
    private $table_users = 'users';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // ========== BEASISWA METHODS ==========
    
    public function getAllBeasiswa() {
        $query = "SELECT * FROM " . $this->table_beasiswa . " 
                  WHERE status = 'aktif' 
                  ORDER BY deadline ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getAllBeasiswaWithStatus() {
        $query = "SELECT * FROM " . $this->table_beasiswa . " 
                  ORDER BY created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getBeasiswaById($id) {
        $query = "SELECT * FROM " . $this->table_beasiswa . " 
                  WHERE id = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function getBeasiswaByFilter($filter = []) {
        $query = "SELECT * FROM " . $this->table_beasiswa . " WHERE status = 'aktif'";
        
        if (isset($filter['penyelenggara'])) {
            $query .= " AND penyelenggara LIKE :penyelenggara";
        }
        
        if (isset($filter['max_nominal'])) {
            $query .= " AND nominal <= :max_nominal";
        }
        
        $query .= " ORDER BY deadline ASC";
        
        $stmt = $this->conn->prepare($query);
        
        if (isset($filter['penyelenggara'])) {
            $stmt->bindValue(':penyelenggara', '%' . $filter['penyelenggara'] . '%');
        }
        
        if (isset($filter['max_nominal'])) {
            $stmt->bindValue(':max_nominal', $filter['max_nominal']);
        }
        
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function createBeasiswa($data) {
        $query = "INSERT INTO " . $this->table_beasiswa . " 
                  (nama_beasiswa, penyelenggara, deskripsi, nominal, deadline, kriteria, status) 
                  VALUES (:nama_beasiswa, :penyelenggara, :deskripsi, :nominal, :deadline, :kriteria, :status)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':nama_beasiswa', $data['nama_beasiswa']);
        $stmt->bindParam(':penyelenggara', $data['penyelenggara']);
        $stmt->bindParam(':deskripsi', $data['deskripsi']);
        $stmt->bindParam(':nominal', $data['nominal']);
        $stmt->bindParam(':deadline', $data['deadline']);
        $stmt->bindParam(':kriteria', $data['kriteria']);
        $stmt->bindParam(':status', $data['status']);
        
        return $stmt->execute();
    }

    public function updateBeasiswa($id, $data) {
        $query = "UPDATE " . $this->table_beasiswa . " 
                  SET nama_beasiswa = :nama_beasiswa, 
                      penyelenggara = :penyelenggara, 
                      deskripsi = :deskripsi, 
                      nominal = :nominal, 
                      deadline = :deadline, 
                      kriteria = :kriteria, 
                      status = :status 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':nama_beasiswa', $data['nama_beasiswa']);
        $stmt->bindParam(':penyelenggara', $data['penyelenggara']);
        $stmt->bindParam(':deskripsi', $data['deskripsi']);
        $stmt->bindParam(':nominal', $data['nominal']);
        $stmt->bindParam(':deadline', $data['deadline']);
        $stmt->bindParam(':kriteria', $data['kriteria']);
        $stmt->bindParam(':status', $data['status']);
        
        return $stmt->execute();
    }

    public function deleteBeasiswa($id) {
        $query = "DELETE FROM " . $this->table_beasiswa . " WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    // ========== APLIKASI METHODS ==========
    
    public function createAplikasi($data) {
        $query = "INSERT INTO " . $this->table_aplikasi . " 
                  (beasiswa_id, user_id, status, berkas, catatan, tanggal_pengajuan) 
                  VALUES (:beasiswa_id, :user_id, :status, :berkas, :catatan, NOW())";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':beasiswa_id', $data['beasiswa_id']);
        $stmt->bindParam(':user_id', $data['user_id']);
        $stmt->bindParam(':status', $data['status']);
        $stmt->bindParam(':berkas', $data['berkas']);
        $stmt->bindParam(':catatan', $data['catatan']);
        
        return $stmt->execute();
    }

    public function getAplikasiByUserId($user_id) {
        $query = "SELECT a.*, b.nama_beasiswa, b.penyelenggara, b.nominal, b.deadline
                  FROM " . $this->table_aplikasi . " a
                  LEFT JOIN " . $this->table_beasiswa . " b ON a.beasiswa_id = b.id
                  WHERE a.user_id = :user_id
                  ORDER BY a.tanggal_pengajuan DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getAllAplikasi() {
        $query = "SELECT a.*, b.nama_beasiswa, b.penyelenggara, u.name as user_name, u.email, u.nim, u.jurusan
                  FROM " . $this->table_aplikasi . " a
                  LEFT JOIN " . $this->table_beasiswa . " b ON a.beasiswa_id = b.id
                  LEFT JOIN " . $this->table_users . " u ON a.user_id = u.id
                  ORDER BY a.tanggal_pengajuan DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function updateStatusAplikasi($id, $status, $alasan = null) {
        if ($alasan) {
            $query = "UPDATE " . $this->table_aplikasi . " 
                      SET status = :status, alasan = :alasan 
                      WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':alasan', $alasan);
        } else {
            $query = "UPDATE " . $this->table_aplikasi . " 
                      SET status = :status 
                      WHERE id = :id";
            $stmt = $this->conn->prepare($query);
        }
        
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    // ========== USER METHODS ==========
    
    public function getAllUsers() {
        $query = "SELECT * FROM " . $this->table_users . " 
                  WHERE role = 'user' 
                  ORDER BY created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    // ========== STATISTIK ==========
    
    public function getStatistik() {
        $stats = [];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_beasiswa . " WHERE status = 'aktif'";
        $stmt = $this->conn->query($query);
        $stats['total_beasiswa'] = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_aplikasi;
        $stmt = $this->conn->query($query);
        $stats['total_aplikasi'] = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_aplikasi . " WHERE status = 'pending'";
        $stmt = $this->conn->query($query);
        $stats['pending'] = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_aplikasi . " WHERE status = 'diterima'";
        $stmt = $this->conn->query($query);
        $stats['diterima'] = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_aplikasi . " WHERE status = 'ditolak'";
        $stmt = $this->conn->query($query);
        $stats['ditolak'] = $stmt->fetch()['total'];

        $query = "SELECT COUNT(*) as total FROM " . $this->table_users . " WHERE role = 'user'";
        $stmt = $this->conn->query($query);
        $stats['total_users'] = $stmt->fetch()['total'];

        return $stats;
    }
}
?>