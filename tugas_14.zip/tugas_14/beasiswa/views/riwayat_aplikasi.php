<?php
/**
 * View Riwayat Aplikasi - Sistem Manajemen Beasiswa
 * File: riwayat_aplikasi.php
 */

require_once __DIR__ . '/../../helpers/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Sistem Manajemen Beasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .riwayat-container {
            max-width: 1000px;
            margin: 40px auto;
        }
        
        .riwayat-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            padding: 30px;
        }
        
        .riwayat-card h2 {
            font-weight: 800;
            margin-bottom: 30px;
            color: #4361ee;
        }
        
        .aplikasi-item {
            background: #f8fafc;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            border-left: 5px solid #4361ee;
            transition: all 0.3s;
        }
        
        .aplikasi-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .aplikasi-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 2px solid #eaeaea;
        }
        
        .aplikasi-title {
            font-weight: 700;
            font-size: 1.3rem;
            color: #1e293b;
        }
        
        .status-badge {
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.95rem;
        }
        
        .status-pending {
            background: linear-gradient(135deg, #ff9e64 0%, #f72585 100%);
            color: white;
        }
        
        .status-diterima {
            background: linear-gradient(135deg, #4ade80 0%, #22c55e 100%);
            color: white;
        }
        
        .status-ditolak {
            background: linear-gradient(135deg, #f87171 0%, #ef4444 100%);
            color: white;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 10px;
        }
        
        .info-label {
            width: 180px;
            font-weight: 600;
            color: #4361ee;
        }
        
        .info-value {
            flex: 1;
            color: #333;
        }
        
        .berkas-link {
            color: #4361ee;
            text-decoration: none;
            font-weight: 600;
        }
        
        .berkas-link:hover {
            text-decoration: underline;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 18px 25px;
            margin-bottom: 25px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?= BASE_URL ?>index.php?page=beasiswa">
                <i class="fas fa-graduation-cap me-2"></i> BEASISWA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>index.php?page=beasiswa">
                            <i class="fas fa-home me-1"></i> Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?= BASE_URL ?>index.php?page=beasiswa&action=riwayat">
                            <i class="fas fa-history me-1"></i> Riwayat
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                           data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?= e($_SESSION['user_name']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= BASE_URL ?>index.php?page=users&action=profile">
                                <i class="fas fa-user me-2"></i> Profil Saya
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container riwayat-container">
        <!-- Flash Message -->
        <?php if ($flash = get_flash()): ?>
        <div class="alert alert-<?= $flash['type'] ?>">
            <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?> me-2"></i>
            <?= e($flash['message']) ?>
        </div>
        <?php endif; ?>

        <div class="riwayat-card">
            <h2><i class="fas fa-history me-2"></i> Riwayat Pengajuan Beasiswa</h2>
            
            <?php if (count($aplikasi) > 0): ?>
                <?php foreach ($aplikasi as $a): ?>
                <div class="aplikasi-item">
                    <div class="aplikasi-header">
                        <div>
                            <div class="aplikasi-title"><?= e($a['nama_beasiswa']) ?></div>
                            <small class="text-muted">
                                <i class="fas fa-building me-2"></i><?= e($a['penyelenggara']) ?>
                            </small>
                        </div>
                        <span class="status-badge status-<?= $a['status'] ?>">
                            <?php
                            $status_text = [
                                'pending' => 'Menunggu',
                                'diterima' => 'Diterima',
                                'ditolak' => 'Ditolak'
                            ];
                            echo $status_text[$a['status']] ?? ucfirst($a['status']);
                            ?>
                        </span>
                    </div>
                    
                    <div class="info-row">
                        <span class="info-label"><i class="fas fa-money-bill-wave me-2"></i> Nominal:</span>
                        <span class="info-value"><?= format_rupiah($a['nominal']) ?></span>
                    </div>
                    
                    <div class="info-row">
                        <span class="info-label"><i class="fas fa-calendar-alt me-2"></i> Deadline:</span>
                        <span class="info-value"><?= format_tanggal($a['deadline']) ?></span>
                    </div>
                    
                    <div class="info-row">
                        <span class="info-label"><i class="fas fa-calendar-check me-2"></i> Tanggal Pengajuan:</span>
                        <span class="info-value"><?= date('d M Y, H:i', strtotime($a['tanggal_pengajuan'])) ?></span>
                    </div>
                    
                    <?php if (!empty($a['berkas'])): ?>
                    <div class="info-row">
                        <span class="info-label"><i class="fas fa-file me-2"></i> Berkas:</span>
                        <span class="info-value">
                            <a href="<?= BASE_URL ?>uploads/berkas/<?= e($a['berkas']) ?>" 
                               class="berkas-link" target="_blank">
                                <i class="fas fa-download me-1"></i> Download Berkas
                            </a>
                        </span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($a['catatan'])): ?>
                    <div class="info-row">
                        <span class="info-label"><i class="fas fa-sticky-note me-2"></i> Catatan:</span>
                        <span class="info-value"><?= e($a['catatan']) ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($a['alasan'])): ?>
                    <div class="info-row">
                        <span class="info-label"><i class="fas fa-comment me-2"></i> Alasan:</span>
                        <span class="info-value text-danger"><?= e($a['alasan']) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="alert alert-info text-center">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Belum ada riwayat pengajuan.</strong><br>
                    Silakan ajukan beasiswa terlebih dahulu.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>