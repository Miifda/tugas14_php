<?php
/**
 * View Detail Beasiswa - Sistem Manajemen Beasiswa
 * File: detail_beasiswa.php
 */

require_once __DIR__ . '/../../helpers/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Sistem Manajemen Beasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .detail-container {
            max-width: 900px;
            margin: 40px auto;
        }
        
        .detail-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .detail-header {
            background: linear-gradient(135deg, #4361ee 0%, #3f37c9 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        
        .detail-header h1 {
            font-weight: 800;
            margin-bottom: 10px;
            font-size: 2rem;
        }
        
        .detail-header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .detail-body {
            padding: 40px;
        }
        
        .info-item {
            margin-bottom: 25px;
            padding-bottom: 25px;
            border-bottom: 1px solid #eaeaea;
        }
        
        .info-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .info-label {
            font-weight: 700;
            color: #4361ee;
            font-size: 1.1rem;
            margin-bottom: 8px;
            display: block;
        }
        
        .info-value {
            font-size: 1.05rem;
            color: #333;
            line-height: 1.8;
        }
        
        .badge-container {
            display: inline-block;
            background: linear-gradient(135deg, #4cc9f0 0%, #4361ee 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 700;
            margin: 5px;
        }
        
        .deadline-container {
            display: inline-block;
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            padding: 10px 25px;
            border-radius: 25px;
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .btn-container {
            text-align: center;
            margin-top: 30px;
            padding-top: 30px;
            border-top: 2px solid #f0f0f0;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #4361ee 0%, #3f37c9 100%);
            border: none;
            padding: 15px 40px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s;
            box-shadow: 0 5px 20px rgba(67, 97, 238, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(67, 97, 238, 0.6);
        }
        
        .btn-secondary {
            background: white;
            color: #4361ee;
            border: 2px solid #4361ee;
            padding: 12px 35px;
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }
        
        .btn-secondary:hover {
            background: #4361ee;
            color: white;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 18px 25px;
            margin-bottom: 25px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?= BASE_URL ?>index.php?page=beasiswa">
                <i class="fas fa-graduation-cap me-2"></i> BEASISWA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= BASE_URL ?>index.php?page=beasiswa">
                            <i class="fas fa-arrow-left me-1"></i> Kembali
                        </a>
                    </li>
                    <?php if (is_logged_in()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                               data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle me-1"></i> <?= e($_SESSION['user_name']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>index.php?page=users&action=profile">
                                    <i class="fas fa-user me-2"></i> Profil Saya
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                                </a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container detail-container">
        <!-- Flash Message -->
        <?php if ($flash = get_flash()): ?>
        <div class="alert alert-<?= $flash['type'] ?>">
            <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?> me-2"></i>
            <?= e($flash['message']) ?>
        </div>
        <?php endif; ?>

        <div class="detail-card">
            <div class="detail-header">
                <h1><?= e($beasiswa['nama_beasiswa']) ?></h1>
                <p><?= e($beasiswa['penyelenggara']) ?></p>
                <div class="mt-3">
                    <span class="badge-container">
                        <i class="fas fa-money-bill-wave me-2"></i>
                        <?= format_rupiah($beasiswa['nominal']) ?>
                    </span>
                    <span class="deadline-container">
                        <i class="fas fa-calendar-alt me-2"></i>
                        Deadline: <?= format_tanggal($beasiswa['deadline']) ?>
                    </span>
                </div>
            </div>
            
            <div class="detail-body">
                <div class="info-item">
                    <span class="info-label">
                        <i class="fas fa-file-alt me-2"></i> Deskripsi
                    </span>
                    <div class="info-value">
                        <?= nl2br(e($beasiswa['deskripsi'])) ?>
                    </div>
                </div>
                
                <div class="info-item">
                    <span class="info-label">
                        <i class="fas fa-clipboard-list me-2"></i> Kriteria Penerima
                    </span>
                    <div class="info-value">
                        <?= nl2br(e($beasiswa['kriteria'])) ?>
                    </div>
                </div>
                
                <div class="info-item">
                    <span class="info-label">
                        <i class="fas fa-info-circle me-2"></i> Informasi Tambahan
                    </span>
                    <div class="info-value">
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle text-success me-2"></i> Status: <strong><?= ucfirst($beasiswa['status']) ?></strong></li>
                            <li><i class="fas fa-calendar-plus me-2"></i> Dibuat pada: <?= date('d M Y, H:i', strtotime($beasiswa['created_at'])) ?></li>
                        </ul>
                    </div>
                </div>
                
                <div class="btn-container">
                    <?php if (is_logged_in()): ?>
                        <?php 
                        $deadline = strtotime($beasiswa['deadline']);
                        $sekarang = strtotime(date('Y-m-d'));
                        ?>
                        <?php if ($deadline >= $sekarang): ?>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#ajukanModal">
                            <i class="fas fa-paper-plane me-2"></i> Ajukan Beasiswa
                        </button>
                        <?php else: ?>
                        <button class="btn btn-secondary" disabled>
                            <i class="fas fa-clock me-2"></i> Deadline Sudah Lewat
                        </button>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="<?= BASE_URL ?>index.php?page=users&action=login" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt me-2"></i> Login untuk Ajukan
                        </a>
                    <?php endif; ?>
                    <a href="<?= BASE_URL ?>index.php?page=beasiswa" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Kembali ke Daftar
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Ajukan Beasiswa -->
    <?php if (is_logged_in() && $deadline >= $sekarang): ?>
    <div class="modal fade" id="ajukanModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-paper-plane me-2"></i> Ajukan Beasiswa: <?= e($beasiswa['nama_beasiswa']) ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="<?= BASE_URL ?>index.php?page=beasiswa&action=ajukan&id=<?= $beasiswa['id'] ?>" 
                      enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>Persyaratan Berkas:</strong><br>
                            - KHS terbaru<br>
                            - Surat Keterangan Aktif Kuliah<br>
                            - Proposal/Surat Lamaran<br>
                            - Dokumen pendukung lainnya
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Upload Berkas <span class="text-danger">*</span></label>
                            <input type="file" class="form-control" name="berkas" accept=".pdf,.doc,.docx" required>
                            <small class="text-muted">Format: PDF, DOC, DOCX (Max 5MB)</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Catatan Tambahan</label>
                            <textarea class="form-control" name="catatan" rows="4" 
                                      placeholder="Tulis alasan mengapa Anda layak mendapatkan beasiswa ini..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            Batal
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i> Ajukan Sekarang
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>