<?php
require_once __DIR__ . '/../../helpers/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Sistem Manajemen Beasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --dark-color: #1e293b;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4edf5 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.85);
            padding: 15px 25px;
            border-radius: 8px;
            margin: 5px 15px;
            transition: all 0.3s;
            font-weight: 600;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.2);
        }
        
        .sidebar .nav-link i {
            margin-right: 12px;
            width: 25px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 25px;
            transition: transform 0.3s;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px 25px;
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        .form-label {
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: none;
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.6);
        }
        
        .btn-secondary {
            background: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }
        
        .btn-secondary:hover {
            background: var(--primary-color);
            color: white;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 18px 25px;
            margin-bottom: 25px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        
        .required {
            color: #ef4444;
            font-weight: bold;
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .info-box {
            background: linear-gradient(135deg, rgba(67, 97, 238, 0.1) 0%, rgba(63, 55, 201, 0.1) 100%);
            border-left: 5px solid var(--primary-color);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center">
            <h4 class="text-white mb-1"><i class="fas fa-crown"></i> ADMIN</h4>
            <small class="text-white-50">Beasiswa Management</small>
        </div>
        <hr class="text-white-50">
        
        <ul class="nav flex-column px-3 mt-3">
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=admin&action=dashboard">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="<?= BASE_URL ?>index.php?page=admin&action=kelola_beasiswa">
                    <i class="fas fa-book-open"></i> Kelola Beasiswa
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=admin&action=kelola_users">
                    <i class="fas fa-users"></i> Kelola Pengguna
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=admin&action=kelola_aplikasi">
                    <i class="fas fa-file-alt"></i> Kelola Aplikasi
                </a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=beasiswa">
                    <i class="fas fa-home"></i> Ke Beranda User
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light mb-4">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle"></i> <?= e($_SESSION['user_name']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>index.php?page=users&action=profile">
                                    <i class="fas fa-user"></i> Profil
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Flash Message -->
        <?php if ($flash = get_flash()): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'danger' ? 'exclamation-circle' : 'info-circle') ?> me-2"></i>
            <?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Page Title -->
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="fw-bold mb-0">
                    <i class="fas fa-edit me-2"></i> Edit Beasiswa
                </h2>
                <p class="text-muted">Update informasi beasiswa "<?= e($beasiswa['nama_beasiswa']) ?>"</p>
            </div>
        </div>

        <!-- Info Box -->
        <div class="info-box">
            <h5 class="mb-3"><i class="fas fa-info-circle me-2"></i> Informasi Beasiswa</h5>
            <div class="row">
                <div class="col-md-4">
                    <p class="mb-2"><strong>ID Beasiswa:</strong></p>
                    <p class="text-muted">#<?= $beasiswa['id'] ?></p>
                </div>
                <div class="col-md-4">
                    <p class="mb-2"><strong>Tanggal Dibuat:</strong></p>
                    <p class="text-muted"><?= date('d M Y, H:i', strtotime($beasiswa['created_at'])) ?></p>
                </div>
                <div class="col-md-4">
                    <p class="mb-2"><strong>Status:</strong></p>
                    <p>
                        <?php if ($beasiswa['status'] == 'aktif'): ?>
                            <span class="badge bg-success">Aktif</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Nonaktif</span>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Form Edit Beasiswa -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-file-alt me-2"></i> Form Update Data</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?= BASE_URL ?>index.php?page=admin&action=edit_beasiswa&id=<?= $beasiswa['id'] ?>">
                    <input type="hidden" name="id" value="<?= $beasiswa['id'] ?>">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label" for="nama_beasiswa">
                                Nama Beasiswa <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="nama_beasiswa" name="nama_beasiswa" 
                                   value="<?= e($beasiswa['nama_beasiswa']) ?>" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label" for="penyelenggara">
                                Penyelenggara <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="penyelenggara" name="penyelenggara" 
                                   value="<?= e($beasiswa['penyelenggara']) ?>" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label" for="nominal">
                                Nominal (Rp) <span class="required">*</span>
                            </label>
                            <input type="number" class="form-control" id="nominal" name="nominal" 
                                   value="<?= $beasiswa['nominal'] ?>" min="0" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label" for="deadline">
                                Deadline Pendaftaran <span class="required">*</span>
                            </label>
                            <input type="date" class="form-control" id="deadline" name="deadline" 
                                   value="<?= $beasiswa['deadline'] ?>" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label" for="deskripsi">
                            Deskripsi Beasiswa <span class="required">*</span>
                        </label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" required><?= e($beasiswa['deskripsi']) ?></textarea>
                        <small class="text-muted">Minimal 50 karakter</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label" for="kriteria">
                            Kriteria Penerima <span class="required">*</span>
                        </label>
                        <textarea class="form-control" id="kriteria" name="kriteria" required><?= e($beasiswa['kriteria']) ?></textarea>
                        <small class="text-muted">Pisahkan dengan enter atau bullet points</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label" for="status">
                            Status Beasiswa <span class="required">*</span>
                        </label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="aktif" <?= $beasiswa['status'] == 'aktif' ? 'selected' : '' ?>>Aktif (Bisa Diajukan)</option>
                            <option value="nonaktif" <?= $beasiswa['status'] == 'nonaktif' ? 'selected' : '' ?>>Nonaktif (Tidak Bisa Diajukan)</option>
                        </select>
                    </div>
                    
                    <div class="d-flex gap-3 mt-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update Beasiswa
                        </button>
                        <a href="<?= BASE_URL ?>index.php?page=admin&action=kelola_beasiswa" class="btn btn-secondary">
                            <i class="fas fa-times me-2"></i> Batal
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Delete Option -->
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i> Hapus Beasiswa</h5>
            </div>
            <div class="card-body">
                <p class="mb-3"><strong>Peringatan:</strong> Tindakan ini akan menghapus beasiswa secara permanen.</p>
                <button class="btn btn-danger" onclick="confirmDelete()">
                    <i class="fas fa-trash me-2"></i> Hapus Beasiswa Ini
                </button>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmDelete() {
            if (confirm('Yakin ingin menghapus beasiswa ini? Tindakan ini tidak dapat dibatalkan!')) {
                window.location.href = '<?= BASE_URL ?>index.php?page=admin&action=hapus_beasiswa&id=<?= $beasiswa['id'] ?>';
            }
        }
        
        // Validasi minimal karakter untuk deskripsi
        document.getElementById('deskripsi').addEventListener('input', function() {
            if (this.value.length < 50) {
                this.setCustomValidity('Deskripsi minimal 50 karakter');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>