<?php
require_once __DIR__ . '/../../helpers/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Sistem Manajemen Beasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --dark-color: #1e293b;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4edf5 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.85);
            padding: 15px 25px;
            border-radius: 8px;
            margin: 5px 15px;
            transition: all 0.3s;
            font-weight: 600;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.2);
        }
        
        .sidebar .nav-link i {
            margin-right: 12px;
            width: 25px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            margin-bottom: 25px;
            transition: transform 0.3s;
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 20px 25px;
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.875rem;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 18px 25px;
            margin-bottom: 25px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        
        .status-badge {
            padding: 6px 15px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.85rem;
        }
        
        .status-pending {
            background: linear-gradient(135deg, #ff9e64 0%, #f72585 100%);
            color: white;
        }
        
        .status-diterima {
            background: linear-gradient(135deg, #4ade80 0%, #22c55e 100%);
            color: white;
        }
        
        .status-ditolak {
            background: linear-gradient(135deg, #f87171 0%, #ef4444 100%);
            color: white;
        }
        
        .stat-box {
            background: white;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: var(--dark-color);
            font-weight: 600;
        }
        
        .aplikasi-item {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
            border-left: 4px solid var(--primary-color);
        }
        
        .aplikasi-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
        }
        
        .modal-content {
            border-radius: 15px;
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="p-4 text-center">
            <h4 class="text-white mb-1"><i class="fas fa-crown"></i> ADMIN</h4>
            <small class="text-white-50">Beasiswa Management</small>
        </div>
        <hr class="text-white-50">
        
        <ul class="nav flex-column px-3 mt-3">
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=admin&action=dashboard">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
             <li class="nav-item">
                <a class="nav-link active" href="<?= BASE_URL ?>index.php?page=admin&action=kelola_aplikasi">
                    <i class="fas fa-file-alt"></i> Kelola Aplikasi
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=admin&action=kelola_beasiswa">
                    <i class="fas fa-book-open"></i> Kelola Beasiswa
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>index.php?page=admin&action=kelola_users">
                    <i class="fas fa-users"></i> Kelola Pengguna
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light mb-4">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle"></i> <?= e($_SESSION['user_name']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>index.php?page=users&action=profile">
                                    <i class="fas fa-user"></i> Profil
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Flash Message -->
        <?php if ($flash = get_flash()): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'danger' ? 'exclamation-circle' : 'info-circle') ?> me-2"></i>
            <?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Page Title -->
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="fw-bold mb-0">
                    <i class="fas fa-file-alt me-2"></i> Kelola Aplikasi Beasiswa
                </h2>
                <p class="text-muted">Review dan kelola semua pengajuan beasiswa</p>
            </div>
        </div>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="stat-box">
                    <div class="stat-number"><?= count($aplikasi) ?></div>
                    <div class="stat-label">Total Aplikasi</div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stat-box">
                    <div class="stat-number"><?= array_filter($aplikasi, fn($a) => $a['status'] == 'pending') ? count(array_filter($aplikasi, fn($a) => $a['status'] == 'pending')) : 0 ?></div>
                    <div class="stat-label">Pending</div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stat-box">
                    <div class="stat-number"><?= array_filter($aplikasi, fn($a) => $a['status'] == 'diterima') ? count(array_filter($aplikasi, fn($a) => $a['status'] == 'diterima')) : 0 ?></div>
                    <div class="stat-label">Diterima</div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stat-box">
                    <div class="stat-number"><?= array_filter($aplikasi, fn($a) => $a['status'] == 'ditolak') ? count(array_filter($aplikasi, fn($a) => $a['status'] == 'ditolak')) : 0 ?></div>
                    <div class="stat-label">Ditolak</div>
                </div>
            </div>
        </div>

        <!-- Filter -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="searchInput" placeholder="Cari aplikasi...">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="filterStatus">
                            <option value="">Semua Status</option>
                            <option value="pending">Pending</option>
                            <option value="diterima">Diterima</option>
                            <option value="ditolak">Ditolak</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select class="form-select" id="filterBeasiswa">
                            <option value="">Semua Beasiswa</option>
                            <?php
                            $beasiswaList = array_unique(array_column($aplikasi, 'nama_beasiswa'));
                            foreach ($beasiswaList as $nama):
                            ?>
                            <option value="<?= $nama ?>"><?= $nama ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Applications List -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-list me-2"></i> Daftar Aplikasi
                    <span class="badge bg-light text-dark ms-2" id="resultCount"><?= count($aplikasi) ?> Aplikasi</span>
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="aplikasiTable">
                        <thead>
                            <tr>
                                <th style="width: 50px;">No</th>
                                <th>Pengguna</th>
                                <th>Beasiswa</th>
                                <th>Nominal</th>
                                <th>Tanggal Ajukan</th>
                                <th>Status</th>
                                <th style="width: 150px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; foreach ($aplikasi as $app): ?>
                            <tr class="aplikasi-row" 
                                data-user="<?= strtolower($app['user_name']) ?>" 
                                data-status="<?= $app['status'] ?>"
                                data-beasiswa="<?= strtolower($app['nama_beasiswa']) ?>">
                                <td><?= $no++ ?></td>
                                <td>
                                    <div class="fw-bold"><?= e($app['user_name']) ?></div>
                                    <small class="text-muted"><?= e($app['nim']) ?> - <?= e($app['jurusan']) ?></small><br>
                                    <small class="text-muted"><?= e($app['email']) ?></small>
                                </td>
                                <td>
                                    <div class="fw-bold"><?= e($app['nama_beasiswa']) ?></div>
                                    <small class="text-muted"><?= e($app['penyelenggara']) ?></small>
                                </td>
                                <td><?= format_rupiah($app['nominal'] ?? 0) ?></td>
                                <td><?= date('d M Y, H:i', strtotime($app['tanggal_pengajuan'])) ?></td>
                                <td>
                                    <span class="status-badge status-<?= $app['status'] ?>">
                                        <?php
                                        $statusLabel = [
                                            'pending' => 'Pending',
                                            'diterima' => 'Diterima',
                                            'ditolak' => 'Ditolak'
                                        ];
                                        echo $statusLabel[$app['status']];
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" onclick="viewDetail(<?= htmlspecialchars(json_encode($app)) ?>)">
                                        <i class="fas fa-eye"></i> Detail
                                    </button>
                                    <?php if ($app['status'] == 'pending'): ?>
                                    <div class="btn-group mt-1" role="group">
                                        <button class="btn btn-sm btn-success" onclick="updateStatus(<?= $app['id'] ?>, 'diterima')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="updateStatus(<?= $app['id'] ?>, 'ditolak')">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Detail Modal -->
    <div class="modal fade" id="detailModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-info-circle me-2"></i> Detail Aplikasi</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="modalContent">
                    <!-- Content will be loaded here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Alasan Modal -->
    <div class="modal fade" id="alasanModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Konfirmasi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="alasanForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Alasan</label>
                            <textarea class="form-control" name="alasan" rows="3" required></textarea>
                            <small class="text-muted">Jelaskan alasan penolakan kepada pemohon</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentAppId = null;
        let currentStatus = null;

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('.aplikasi-row');
            let count = 0;
            
            rows.forEach(row => {
                const user = row.getAttribute('data-user');
                const beasiswa = row.getAttribute('data-beasiswa');
                if (user.includes(searchTerm) || beasiswa.includes(searchTerm)) {
                    row.style.display = '';
                    count++;
                } else {
                    row.style.display = 'none';
                }
            });
            
            document.getElementById('resultCount').textContent = count + ' Aplikasi';
        });
        
        // Filter by status
        document.getElementById('filterStatus').addEventListener('change', function() {
            const status = this.value;
            const rows = document.querySelectorAll('.aplikasi-row');
            
            rows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');
                if (!status || rowStatus === status) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
        
        // Filter by beasiswa
        document.getElementById('filterBeasiswa').addEventListener('change', function() {
            const beasiswa = this.value.toLowerCase();
            const rows = document.querySelectorAll('.aplikasi-row');
            
            rows.forEach(row => {
                const rowBeasiswa = row.getAttribute('data-beasiswa');
                if (!beasiswa || rowBeasiswa.includes(beasiswa)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
        
        function viewDetail(app) {
            const content = `
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6><i class="fas fa-user me-2"></i>Informasi Pengguna</h6>
                        <p class="mb-1"><strong>Nama:</strong> ${escapeHtml(app.user_name)}</p>
                        <p class="mb-1"><strong>NIM:</strong> ${escapeHtml(app.nim)}</p>
                        <p class="mb-1"><strong>Jurusan:</strong> ${escapeHtml(app.jurusan)}</p>
                        <p class="mb-1"><strong>Email:</strong> ${escapeHtml(app.email)}</p>
                    </div>
                    <div class="col-md-6">
                        <h6><i class="fas fa-book-open me-2"></i>Informasi Beasiswa</h6>
                        <p class="mb-1"><strong>Nama:</strong> ${escapeHtml(app.nama_beasiswa)}</p>
                        <p class="mb-1"><strong>Penyelenggara:</strong> ${escapeHtml(app.penyelenggara)}</p>
                        <p class="mb-1"><strong>Nominal:</strong> Rp ${parseInt(app.nominal).toLocaleString('id-ID')}</p>
                    </div>
                </div>
                <div class="mb-3">
                    <h6><i class="fas fa-clock me-2"></i>Tanggal Pengajuan</h6>
                    <p>${new Date(app.tanggal_pengajuan).toLocaleDateString('id-ID', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    })}</p>
                </div>
                <div class="mb-3">
                    <h6><i class="fas fa-info-circle me-2"></i>Status</h6>
                    <span class="status-badge status-${app.status}">
                        ${app.status === 'pending' ? 'Pending' : (app.status === 'diterima' ? 'Diterima' : 'Ditolak')}
                    </span>
                </div>
                ${app.catatan ? `
                <div class="mb-3">
                    <h6><i class="fas fa-sticky-note me-2"></i>Catatan Pemohon</h6>
                    <p class="bg-light p-3 rounded">${escapeHtml(app.catatan)}</p>
                </div>
                ` : ''}
                ${app.alasan ? `
                <div class="mb-3">
                    <h6><i class="fas fa-comment me-2"></i>Alasan ${app.status === 'diterima' ? 'Penerimaan' : 'Penolakan'}</h6>
                    <p class="bg-light p-3 rounded text-danger">${escapeHtml(app.alasan)}</p>
                </div>
                ` : ''}
                ${app.berkas ? `
                <div class="mb-3">
                    <h6><i class="fas fa-file me-2"></i>Berkas</h6>
                    <a href="uploads/berkas/${app.berkas}" class="btn btn-primary" target="_blank">
                        <i class="fas fa-download me-2"></i>Download Berkas
                    </a>
                </div>
                ` : ''}
            `;
            
            document.getElementById('modalContent').innerHTML = content;
            const modal = new bootstrap.Modal(document.getElementById('detailModal'));
            modal.show();
        }
        
        function updateStatus(id, status) {
            currentAppId = id;
            currentStatus = status;
            
            if (status === 'diterima') {
                if (confirm('Yakin ingin menerima aplikasi ini?')) {
                    document.getElementById('alasanForm').action = '<?= BASE_URL ?>index.php?page=admin&action=update_status&id=' + id + '&status=' + status;
                    document.querySelector('#alasanModal .modal-title').textContent = 'Alasan Penerimaan';
                    document.querySelector('[name="alasan"]').placeholder = 'Tulis alasan penerimaan (opsional)...';
                    document.querySelector('[name="alasan"]').required = false;
                    
                    const modal = new bootstrap.Modal(document.getElementById('alasanModal'));
                    modal.show();
                }
            } else {
                document.getElementById('alasanForm').action = '<?= BASE_URL ?>index.php?page=admin&action=update_status&id=' + id + '&status=' + status;
                document.querySelector('#alasanModal .modal-title').textContent = 'Alasan Penolakan';
                document.querySelector('[name="alasan"]').placeholder = 'Tulis alasan penolakan kepada pemohon...';
                document.querySelector('[name="alasan"]').required = true;
                
                const modal = new bootstrap.Modal(document.getElementById('alasanModal'));
                modal.show();
            }
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }
    </script>
</body>
</html>