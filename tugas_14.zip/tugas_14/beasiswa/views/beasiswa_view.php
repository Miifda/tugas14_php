<?php
/**
 * View Halaman Utama Beasiswa - Sistem Manajemen Beasiswa
 * File: beasiswa_view.php
 */

require_once __DIR__ . '/../../helpers/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Sistem Manajemen Beasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --warning-color: #f72585;
            --dark-color: #1e293b;
            --light-color: #f8fafc;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        
        .navbar-brand {
            font-weight: 800;
            font-size: 1.6rem;
            color: var(--primary-color) !important;
        }
        
        .nav-link {
            font-weight: 600;
            color: var(--dark-color) !important;
            transition: color 0.3s;
        }
        
        .nav-link:hover {
            color: var(--primary-color) !important;
        }
        
        .hero-section {
            background: linear-gradient(135deg, rgba(67, 97, 238, 0.9) 0%, rgba(63, 55, 201, 0.9) 100%), 
                        url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1600');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 80px 0;
            text-align: center;
        }
        
        .hero-section h1 {
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .hero-section p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .search-box {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            transition: all 0.3s ease;
            background: white;
        }
        
        .card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(67, 97, 238, 0.3);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 18px 25px;
            font-weight: 700;
            font-size: 1.3rem;
        }
        
        .card-body {
            padding: 25px;
        }
        
        .beasiswa-card {
            border-left: 6px solid var(--primary-color);
            position: relative;
            overflow: hidden;
        }
        
        .beasiswa-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 6px;
            height: 100%;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }
        
        .deadline-badge {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 700;
            font-size: 0.95rem;
            display: inline-block;
            margin-top: 10px;
        }
        
        .nominal-badge {
            background: linear-gradient(135deg, #4cc9f0 0%, #4361ee 100%);
            color: white;
            padding: 6px 18px;
            border-radius: 20px;
            font-weight: 700;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: none;
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.6);
        }
        
        .btn-outline-primary {
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
            padding: 10px 25px;
            border-radius: 10px;
            font-weight: 700;
            transition: all 0.3s;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-3px);
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 18px 25px;
            margin-bottom: 25px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        
        .stat-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: white;
            font-size: 28px;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: var(--dark-color);
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .footer {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px 0;
            margin-top: 50px;
            border-top: 3px solid var(--primary-color);
        }
        
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2rem;
            }
            
            .stat-card {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?= BASE_URL ?>index.php?page=beasiswa">
                <i class="fas fa-graduation-cap me-2"></i> BEASISWA
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link <?= (!isset($_GET['action']) || $_GET['action'] == 'index') ? 'active' : '' ?>" 
                           href="<?= BASE_URL ?>index.php?page=beasiswa">
                            <i class="fas fa-home me-1"></i> Beranda
                        </a>
                    </li>
                    <?php if (is_logged_in()): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= isset($_GET['action']) && $_GET['action'] == 'riwayat' ? 'active' : '' ?>" 
                               href="<?= BASE_URL ?>index.php?page=beasiswa&action=riwayat">
                                <i class="fas fa-history me-1"></i> Riwayat
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" 
                               data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle me-1"></i> <?= e($_SESSION['user_name']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>index.php?page=users&action=profile">
                                    <i class="fas fa-user me-2"></i> Profil Saya
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>index.php?page=users&action=logout">
                                    <i class="fas fa-sign-out-alt me-2"></i> Logout
                                </a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link <?= isset($_GET['action']) && $_GET['action'] == 'login' ? 'active' : '' ?>" 
                               href="<?= BASE_URL ?>index.php?page=users&action=login">
                                <i class="fas fa-sign-in-alt me-1"></i> Login
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <h1><i class="fas fa-book-open"></i> Temukan Beasiswa Impianmu</h1>
            <p>Sistem manajemen beasiswa terpadu untuk membantu mahasiswa mendapatkan kesempatan pendidikan terbaik</p>
            <a href="#beasiswa" class="btn btn-light btn-lg px-5">
                <i class="fas fa-search me-2"></i> Lihat Beasiswa
            </a>
        </div>
    </section>

    <div class="container my-5">
        <!-- Flash Message -->
        <?php if ($flash = get_flash()): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : ($flash['type'] === 'danger' ? 'exclamation-circle' : 'info-circle') ?> me-2"></i>
            <?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <!-- Statistik -->
        <div class="row mb-5">
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="stat-number"><?= $stats['total_beasiswa'] ?></div>
                    <div class="stat-label">Beasiswa Aktif</div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-number"><?= $stats['total_aplikasi'] ?></div>
                    <div class="stat-label">Total Pengajuan</div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-number"><?= $stats['pending'] ?></div>
                    <div class="stat-label">Menunggu</div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-number"><?= $stats['diterima'] ?></div>
                    <div class="stat-label">Diterima</div>
                </div>
            </div>
        </div>

        <!-- Search Box -->
        <div class="card search-box mb-5">
            <h5 class="fw-bold mb-4"><i class="fas fa-search me-2"></i> Cari Beasiswa</h5>
            <form method="GET" action="<?= BASE_URL ?>index.php">
                <input type="hidden" name="page" value="beasiswa">
                <input type="hidden" name="action" value="cari">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Penyelenggara</label>
                        <input type="text" class="form-control" name="penyelenggara" 
                               placeholder="Cari berdasarkan penyelenggara..." 
                               value="<?= isset($_GET['penyelenggara']) ? e($_GET['penyelenggara']) : '' ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Maksimal Nominal</label>
                        <input type="number" class="form-control" name="max_nominal" 
                               placeholder="Contoh: 10000000" 
                               value="<?= isset($_GET['max_nominal']) ? e($_GET['max_nominal']) : '' ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-2"></i> Cari
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Daftar Beasiswa -->
        <h2 class="fw-bold mb-4" id="beasiswa"><i class="fas fa-list me-2"></i> Beasiswa Tersedia</h2>
        
        <?php if (count($beasiswa) > 0): ?>
        <div class="row">
            <?php foreach ($beasiswa as $b): ?>
            <div class="col-md-6">
                <div class="card beasiswa-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h5 class="card-title fw-bold mb-2"><?= e($b['nama_beasiswa']) ?></h5>
                                <p class="text-muted mb-2">
                                    <i class="fas fa-building me-2"></i><?= e($b['penyelenggara']) ?>
                                </p>
                            </div>
                            <span class="nominal-badge">
                                <i class="fas fa-money-bill-wave me-1"></i>
                                <?= format_rupiah($b['nominal']) ?>
                            </span>
                        </div>
                        
                        <p class="card-text text-muted mb-3">
                            <?= substr(e($b['deskripsi']), 0, 150) ?>...
                        </p>
                        
                        <div class="mb-3">
                            <span class="deadline-badge">
                                <i class="fas fa-calendar-alt me-2"></i>
                                Deadline: <?= format_tanggal($b['deadline']) ?>
                            </span>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="<?= BASE_URL ?>index.php?page=beasiswa&action=detail&id=<?= $b['id'] ?>" 
                               class="btn btn-outline-primary">
                                <i class="fas fa-info-circle me-2"></i> Detail
                            </a>
                            <?php if (is_logged_in()): ?>
                            <button class="btn btn-primary" data-bs-toggle="modal" 
                                    data-bs-target="#ajukanModal<?= $b['id'] ?>">
                                <i class="fas fa-paper-plane me-2"></i> Ajukan
                            </button>
                            <?php else: ?>
                            <a href="<?= BASE_URL ?>index.php?page=users&action=login" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-2"></i> Login untuk Ajukan
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Modal Ajukan Beasiswa -->
            <?php if (is_logged_in()): ?>
            <div class="modal fade" id="ajukanModal<?= $b['id'] ?>" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <i class="fas fa-paper-plane me-2"></i> Ajukan Beasiswa
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <form method="POST" action="<?= BASE_URL ?>index.php?page=beasiswa&action=ajukan&id=<?= $b['id'] ?>" 
                              enctype="multipart/form-data">
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Nama Beasiswa</label>
                                    <input type="text" class="form-control" value="<?= e($b['nama_beasiswa']) ?>" disabled>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Penyelenggara</label>
                                    <input type="text" class="form-control" value="<?= e($b['penyelenggara']) ?>" disabled>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Deadline</label>
                                    <input type="text" class="form-control" value="<?= format_tanggal($b['deadline']) ?>" disabled>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Upload Berkas <span class="text-danger">*</span></label>
                                    <input type="file" class="form-control" name="berkas" accept=".pdf,.doc,.docx" required>
                                    <small class="text-muted">Format: PDF, DOC, DOCX (Max 5MB)</small>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Catatan Tambahan</label>
                                    <textarea class="form-control" name="catatan" rows="3" 
                                              placeholder="Tulis catatan atau alasan mengapa Anda layak mendapatkan beasiswa ini..."></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    Batal
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i> Ajukan Sekarang
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle me-2"></i>
            <strong>Belum ada beasiswa yang tersedia.</strong><br>
            Silakan cek kembali nanti atau hubungi administrator.
        </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <p class="mb-0">&copy; 2026 Sistem Manajemen Beasiswa. All rights reserved.</p>
                    <p class="text-muted small">Platform terpadu untuk pengelolaan beasiswa mahasiswa</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scroll untuk anchor link
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>