<?php
/**
 * Controller User - Sistem Manajemen Beasiswa
 * File: UserController.php
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

class UserController {
    private $conn;
    private $table_users = 'users';
    private $table_beasiswa = 'beasiswa';
    private $table_aplikasi = 'aplikasi_beasiswa';

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function login() {
        if (is_logged_in()) {
            if ($_SESSION['user_role'] === 'admin') {
                header('Location: index.php?page=admin&action=dashboard');
            } else {
                header('Location: index.php?page=beasiswa');
            }
            exit();
        }
        
        include __DIR__ . '/../auth/login.php';
    }

    public function prosesLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];

            $query = "SELECT * FROM " . $this->table_users . " WHERE email = :email LIMIT 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                if ($user['status'] === 'nonaktif') {
                    set_flash('Akun Anda telah dinonaktifkan. Silakan hubungi administrator.', 'danger');
                    header('Location: index.php?page=users&action=login');
                    exit();
                }
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['user_status'] = $user['status'];
                
                set_flash('Selamat datang, ' . $user['name'] . '!', 'success');
                
                if ($user['role'] === 'admin') {
                    header('Location: index.php?page=admin&action=dashboard');
                } else {
                    header('Location: index.php?page=beasiswa');
                }
                exit();
            } else {
                set_flash('Email atau password salah!', 'danger');
                header('Location: index.php?page=users&action=login');
                exit();
            }
        }
    }

    public function logout() {
        session_unset();
        session_destroy();
        set_flash('Anda berhasil logout', 'success');
        header('Location: index.php?page=users&action=login');
        exit();
    }

    public function register() {
        if (is_logged_in()) {
            header('Location: index.php?page=beasiswa');
            exit();
        }
        
        include __DIR__ . '/../auth/register.php';
    }

    public function prosesRegister() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
            $nim = trim($_POST['nim']);
            $jurusan = trim($_POST['jurusan']);
            $semester = trim($_POST['semester']);
            $no_hp = trim($_POST['no_hp']);

            if (empty($name) || empty($email) || empty($password)) {
                set_flash('Semua field wajib diisi!', 'danger');
                header('Location: index.php?page=users&action=register');
                exit();
            }

            if ($password !== $confirm_password) {
                set_flash('Password dan konfirmasi password tidak sama!', 'danger');
                header('Location: index.php?page=users&action=register');
                exit();
            }

            if (strlen($password) < 6) {
                set_flash('Password minimal 6 karakter!', 'danger');
                header('Location: index.php?page=users&action=register');
                exit();
            }

            $query = "SELECT id FROM " . $this->table_users . " WHERE email = :email";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                set_flash('Email sudah terdaftar!', 'danger');
                header('Location: index.php?page=users&action=register');
                exit();
            }

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $query = "INSERT INTO " . $this->table_users . " 
                      (name, email, password, role, nim, jurusan, semester, no_hp, status) 
                      VALUES (:name, :email, :password, :role, :nim, :jurusan, :semester, :no_hp, :status)";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':role', $role = 'user');
            $stmt->bindParam(':nim', $nim);
            $stmt->bindParam(':jurusan', $jurusan);
            $stmt->bindParam(':semester', $semester);
            $stmt->bindParam(':no_hp', $no_hp);
            $stmt->bindParam(':status', $status = 'aktif');
            
            if ($stmt->execute()) {
                set_flash('Registrasi berhasil! Silakan login untuk melanjutkan.', 'success');
                header('Location: index.php?page=users&action=login');
                exit();
            } else {
                set_flash('Gagal registrasi, silakan coba lagi.', 'danger');
                header('Location: index.php?page=users&action=register');
                exit();
            }
        }
    }

    public function profile() {
        if (!is_logged_in()) {
            set_flash('Anda harus login untuk mengakses halaman ini!', 'warning');
            header('Location: index.php?page=users&action=login');
            exit();
        }
        
        $query = "SELECT * FROM " . $this->table_users . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $_SESSION['user_id']);
        $stmt->execute();
        
        $user = $stmt->fetch();
        
        $query_stats = "SELECT 
                        COUNT(*) as total_aplikasi,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                        SUM(CASE WHEN status = 'diterima' THEN 1 ELSE 0 END) as diterima,
                        SUM(CASE WHEN status = 'ditolak' THEN 1 ELSE 0 END) as ditolak
                        FROM " . $this->table_aplikasi . " 
                        WHERE user_id = :user_id";
        
        $stmt_stats = $this->conn->prepare($query_stats);
        $stmt_stats->bindParam(':user_id', $_SESSION['user_id']);
        $stmt_stats->execute();
        
        $stats = $stmt_stats->fetch();
        
        $data = [
            'user' => $user,
            'stats' => $stats,
            'page_title' => 'Profil Saya'
        ];
        
        extract($data);
        include __DIR__ . '/../views/profile.php';
    }

    public function updateProfile() {
        if (!is_logged_in()) {
            set_flash('Anda harus login untuk mengakses halaman ini!', 'warning');
            header('Location: index.php?page=users&action=login');
            exit();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $nim = $_POST['nim'];
            $jurusan = $_POST['jurusan'];
            $semester = $_POST['semester'];
            $no_hp = $_POST['no_hp'];
            
            $foto = $_POST['foto_lama'];
            if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
                $target_dir = "uploads/foto/";
                if (!file_exists($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                
                $file_extension = pathinfo($_FILES["foto"]["name"], PATHINFO_EXTENSION);
                $new_filename = 'foto_' . $_SESSION['user_id'] . '_' . time() . '.' . $file_extension;
                $target_file = $target_dir . $new_filename;
                
                if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                    $foto = $new_filename;
                }
            }
            
            $query = "UPDATE " . $this->table_users . " 
                      SET name = :name, email = :email, nim = :nim, 
                          jurusan = :jurusan, semester = :semester, 
                          no_hp = :no_hp, foto = :foto
                      WHERE id = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $_SESSION['user_id']);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':nim', $nim);
            $stmt->bindParam(':jurusan', $jurusan);
            $stmt->bindParam(':semester', $semester);
            $stmt->bindParam(':no_hp', $no_hp);
            $stmt->bindParam(':foto', $foto);
            
            if ($stmt->execute()) {
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                
                set_flash('Profil berhasil diperbarui!', 'success');
            } else {
                set_flash('Gagal memperbarui profil!', 'danger');
            }
            
            header('Location: index.php?page=users&action=profile');
            exit();
        }
    }

    public function updatePassword() {
        if (!is_logged_in()) {
            set_flash('Anda harus login untuk mengakses halaman ini!', 'warning');
            header('Location: index.php?page=users&action=login');
            exit();
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            $query = "SELECT password FROM " . $this->table_users . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $_SESSION['user_id']);
            $stmt->execute();
            
            $user = $stmt->fetch();
            
            if (!password_verify($current_password, $user['password'])) {
                set_flash('Password lama salah!', 'danger');
                header('Location: index.php?page=users&action=profile');
                exit();
            }
            
            if ($new_password !== $confirm_password) {
                set_flash('Password baru dan konfirmasi tidak sama!', 'danger');
                header('Location: index.php?page=users&action=profile');
                exit();
            }
            
            if (strlen($new_password) < 6) {
                set_flash('Password minimal 6 karakter!', 'danger');
                header('Location: index.php?page=users&action=profile');
                exit();
            }
            
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $query = "UPDATE " . $this->table_users . " SET password = :password WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $_SESSION['user_id']);
            $stmt->bindParam(':password', $hashed_password);
            
            if ($stmt->execute()) {
                set_flash('Password berhasil diperbarui!', 'success');
            } else {
                set_flash('Gagal memperbarui password!', 'danger');
            }
            
            header('Location: index.php?page=users&action=profile');
            exit();
        }
    }
}
?>