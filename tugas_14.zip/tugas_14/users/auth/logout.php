<?php
/**
 * View Logout - Sistem Manajemen Beasiswa
 * File: logout.php
 */

require_once __DIR__ . '/../../helpers/auth.php';

// Panggil fungsi logout dari helper
logout();
?>