<?php
/**
 * View Register - Sistem Manajemen Beasiswa
 * File: register.php
 */

$title = "Daftar - Sistem Manajemen Beasiswa";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .register-container {
            max-width: 600px;
            width: 100%;
        }
        
        .register-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }
        
        .register-header {
            background: linear-gradient(135deg, #4361ee 0%, #3f37c9 100%);
            padding: 40px 30px;
            text-align: center;
        }
        
        .register-header i {
            font-size: 60px;
            color: white;
            margin-bottom: 20px;
        }
        
        .register-header h2 {
            color: white;
            font-weight: 800;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .register-header p {
            color: rgba(255, 255, 255, 0.85);
            font-size: 1.05rem;
        }
        
        .register-body {
            padding: 40px 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 8px;
            display: block;
        }
        
        .form-control {
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #4361ee;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
        }
        
        .btn-register {
            background: linear-gradient(135deg, #4361ee 0%, #3f37c9 100%);
            border: none;
            padding: 14px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 1.05rem;
            width: 100%;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.4);
        }
        
        .btn-register:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.6);
        }
        
        .login-link {
            text-align: center;
            margin-top: 25px;
            color: #64748b;
        }
        
        .login-link a {
            color: #4361ee;
            font-weight: 700;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .login-link a:hover {
            color: #3f37c9;
            text-decoration: underline;
        }
        
        .alert {
            border-radius: 12px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        
        .step-indicator {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 30px;
        }
        
        .step-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #cbd5e1;
            transition: all 0.3s;
        }
        
        .step-dot.active {
            background: #4361ee;
            transform: scale(1.3);
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-card">
            <div class="register-header">
                <i class="fas fa-user-plus"></i>
                <h2>Daftar Akun Baru</h2>
                <p>Buat akun untuk mengakses sistem beasiswa</p>
            </div>
            
            <div class="register-body">
                <?php if ($flash = get_flash()): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?> me-2"></i>
                    <?= e($flash['message']) ?>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="<?= BASE_URL ?>index.php?page=users&action=proses_register">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="name">
                                    <i class="fas fa-user me-2"></i> Nama Lengkap
                                </label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       placeholder="Masukkan nama lengkap" required 
                                       value="<?= isset($_POST['name']) ? e($_POST['name']) : '' ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="nim">
                                    <i class="fas fa-id-card me-2"></i> NIM
                                </label>
                                <input type="text" class="form-control" id="nim" name="nim" 
                                       placeholder="Masukkan NIM" required 
                                       value="<?= isset($_POST['nim']) ? e($_POST['nim']) : '' ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="jurusan">
                                    <i class="fas fa-university me-2"></i> Jurusan
                                </label>
                                <input type="text" class="form-control" id="jurusan" name="jurusan" 
                                       placeholder="Masukkan jurusan" required 
                                       value="<?= isset($_POST['jurusan']) ? e($_POST['jurusan']) : '' ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="semester">
                                    <i class="fas fa-calendar-alt me-2"></i> Semester
                                </label>
                                <select class="form-control" id="semester" name="semester" required>
                                    <option value="">Pilih Semester</option>
                                    <?php for($i = 1; $i <= 14; $i++): ?>
                                    <option value="<?= $i ?>" <?= (isset($_POST['semester']) && $_POST['semester'] == $i) ? 'selected' : '' ?>>
                                        Semester <?= $i ?>
                                    </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="no_hp">
                            <i class="fas fa-phone me-2"></i> No. HP
                        </label>
                        <input type="tel" class="form-control" id="no_hp" name="no_hp" 
                               placeholder="Masukkan nomor HP" required 
                               value="<?= isset($_POST['no_hp']) ? e($_POST['no_hp']) : '' ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="email">
                            <i class="fas fa-envelope me-2"></i> Email
                        </label>
                        <input type="email" class="form-control" id="email" name="email" 
                               placeholder="Masukkan email" required 
                               value="<?= isset($_POST['email']) ? e($_POST['email']) : '' ?>">
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="password">
                                    <i class="fas fa-lock me-2"></i> Password
                                </label>
                                <input type="password" class="form-control" id="password" name="password" 
                                       placeholder="Minimal 6 karakter" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="confirm_password">
                                    <i class="fas fa-lock me-2"></i> Konfirmasi Password
                                </label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                       placeholder="Ulangi password" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" id="terms" required>
                        <label class="form-check-label" for="terms">
                            Saya setuju dengan <a href="#" class="text-primary">Syarat dan Ketentuan</a> yang berlaku
                        </label>
                    </div>
                    
                    <button type="submit" class="btn btn-register">
                        <i class="fas fa-user-plus me-2"></i> Daftar Sekarang
                    </button>
                </form>
                
                <div class="login-link">
                    <p>Sudah punya akun? <a href="<?= BASE_URL ?>index.php?page=users&action=login">Login di sini</a></p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validasi password match
        document.addEventListener('DOMContentLoaded', function() {
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm_password');
            const registerBtn = document.querySelector('.btn-register');
            
            function validatePassword() {
                if (password.value !== confirmPassword.value) {
                    confirmPassword.setCustomValidity('Password tidak sama!');
                    registerBtn.disabled = true;
                } else {
                    confirmPassword.setCustomValidity('');
                    registerBtn.disabled = false;
                }
            }
            
            password.addEventListener('keyup', validatePassword);
            confirmPassword.addEventListener('keyup', validatePassword);
        });
    </script>
</body>
</html>