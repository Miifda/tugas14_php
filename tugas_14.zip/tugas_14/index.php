<?php
/**
 * Router Utama - Sistem Manajemen Beasiswa
 * File: index.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BASE_URL', 'http://localhost/Gen_4/tugas_14/');

// ============================================
// SOLUSI: Redirect root URL ke login page
// ============================================
if (empty($_GET['page']) && empty($_GET['action'])) {
    // Jika belum login, redirect ke login
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . 'index.php?page=users&action=login');
        exit();
    } 
    // Jika sudah login sebagai admin
    elseif ($_SESSION['user_role'] === 'admin') {
        header('Location: ' . BASE_URL . 'index.php?page=admin&action=dashboard');
        exit();
    } 
    // Jika sudah login sebagai user biasa
    else {
        header('Location: ' . BASE_URL . 'index.php?page=beasiswa&action=dashboard');
        exit();
    }
}

// Autoload classes (lanjutkan kode existing...)
spl_autoload_register(function ($class_name) {
    // ... kode autoloader existing ...
});

spl_autoload_register(function ($class_name) {
    $paths = [
        'config/',
        'helpers/',
        'beasiswa/controllers/',
        'beasiswa/models/',
        'users/controllers/'
    ];
    
    foreach ($paths as $path) {
        $file = __DIR__ . DIRECTORY_SEPARATOR . $path . $class_name . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $page = $_GET['page'] ?? 'users';
    $action = $_GET['action'] ?? 'login';
    
    if ($page === 'users' && $action === 'proses_login') {
        require_once __DIR__ . '/users/controllers/UserController.php';
        $controller = new UserController();
        $controller->prosesLogin();
        exit();
    }
    
    if ($page === 'users' && $action === 'proses_register') {
        require_once __DIR__ . '/users/controllers/UserController.php';
        $controller = new UserController();
        $controller->prosesRegister();
        exit();
    }
    
    if ($page === 'users' && $action === 'update_profile') {
        require_once __DIR__ . '/users/controllers/UserController.php';
        $controller = new UserController();
        $controller->updateProfile();
        exit();
    }
    
    if ($page === 'users' && $action === 'update_password') {
        require_once __DIR__ . '/users/controllers/UserController.php';
        $controller = new UserController();
        $controller->updatePassword();
        exit();
    }
    
    if ($page === 'beasiswa' && $action === 'ajukan') {
        $id = $_GET['id'] ?? 0;
        require_once __DIR__ . '/beasiswa/controllers/BeasiswaController.php';
        $controller = new BeasiswaController();
        $controller->ajukan($id);
        exit();
    }
}

// Handle GET requests
$page = isset($_GET['page']) ? $_GET['page'] : 'beasiswa';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

try {
    switch ($page) {
        case 'beasiswa':
            $controller = new BeasiswaController();
            switch ($action) {
                case 'index':
                    $controller->index();
                    break;
                case 'detail':
                    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                    if ($id > 0) {
                        $controller->detail($id);
                    } else {
                        set_flash('ID beasiswa tidak valid', 'danger');
                        $controller->index();
                    }
                    break;
                case 'riwayat':
                    $controller->riwayat();
                    break;
                case 'cari':
                    $controller->cari();
                    break;
                default:
                    $controller->index();
            }
            break;
            
        case 'users':
            $controller = new UserController();
            switch ($action) {
                case 'login':
                    $controller->login();
                    break;
                case 'logout':
                    $controller->logout();
                    break;
                case 'register':
                    $controller->register();
                    break;
                case 'profile':
                    $controller->profile();
                    break;
                default:
                    $controller->login();
            }
            break;
            
        case 'admin':
            // Cek apakah admin sudah login
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                set_flash('Anda harus login sebagai admin untuk mengakses halaman ini', 'warning');
                header('Location: index.php?page=users&action=login');
                exit();
            }
            
            require_once __DIR__ . '/beasiswa/controllers/BeasiswaController.php';
            $controller = new BeasiswaController();
            
            switch ($action) {
                case 'dashboard':
                    $controller->adminDashboard();
                    break;
                case 'kelola_beasiswa':
                    $controller->kelolaBeasiswa();
                    break;
                case 'kelola_users':
                    $controller->kelolaUsers();
                    break;
                case 'kelola_aplikasi':
                    $controller->kelolaAplikasi();
                    break;
                case 'tambah_beasiswa':
                    $controller->tambahBeasiswa();
                    break;
                case 'edit_beasiswa':
                    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                    $id > 0 ? $controller->editBeasiswa($id) : set_flash('ID tidak valid', 'danger');
                    break;
                case 'hapus_beasiswa':
                    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                    $id > 0 ? $controller->hapusBeasiswa($id) : set_flash('ID tidak valid', 'danger');
                    break;
                case 'update_status':
                    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
                    $status = isset($_GET['status']) ? $_GET['status'] : '';
                    $id > 0 && !empty($status) ? $controller->updateStatusAplikasi($id, $status) : set_flash('Data tidak valid', 'danger');
                    break;
                default:
                    $controller->adminDashboard();
            }
            break;
            
        default:
            header('Location: index.php?page=beasiswa');
            exit();
    }
    
} catch (Exception $e) {
    echo '<div class="container mt-5">';
    echo '<div class="alert alert-danger">';
    echo '<h4>Error:</h4>';
    echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '</div></div>';
}
?>